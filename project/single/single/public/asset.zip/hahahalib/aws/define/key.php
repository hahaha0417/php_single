<?php

namespace hahahalib\aws\define;

use Aws\S3\S3Client;
use Aws\Exception\AwsException;


class key
{
    const REGION = "region";
    const VERSION = "version";
    const CREDENTIALS = "credentials";
    const KEY = "key";
    const KEY_ = "Key";
    const BODY = "Body";
    const SECRET = "secret";
    const BUCKET = 'Bucket';
    const SOURCE_FILE = 'SourceFile';
    const LATEST = 'latest';
    const CONTENT_TYPE = 'ContentType';
    const CACHE_CONTROL = 'CacheControl';
} 