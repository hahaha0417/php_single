<?php

namespace hahahalib\function;

/*

use hahahalib\function\key as key;
use hahahalib\function\key as function_key;

*/
class key
{
    const HTTPS = "HTTPS";
    const OFF = "off";
    const HTTP_X_FORWARDED_PROTO = "HTTP_X_FORWARDED_PROTO";
    const HTTP_FRONT_END_HTTPS = "HTTP_FRONT_END_HTTPS";
    const CLI = "cli";
    const REQUEST_METHOD = "REQUEST_METHOD";
    const GET = "GET";
    const POST = "POST";
   
}