# php hahahalib

方針 : 
1. 上班用
2. lite
3. 沒有規劃做維護
4. php獨有，還是使用單例
5. 降低library的各方面製作


有用 : 
php-html-parser \
https://github.com/paquettg/php-html-parser \
mihaeu/html-formatter \
https://github.com/paquettg/mihaeu/html-formatter

大量cache database \
重要cache php file
